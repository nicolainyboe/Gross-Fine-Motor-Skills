# Gross-Fine-Motor-Skills
Vores hub til kode, pull og push nye updates


Kør test.html, i chrome developer - cmd+shift+p søg efter sensors og test deviceorientation. 
